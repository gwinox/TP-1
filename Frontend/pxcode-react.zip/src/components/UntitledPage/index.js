import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import styles from './index.module.scss';

function UntitledPage(props) {
  return (
    <div
      className={cn(styles.root, props.className, 'untitled-page')}
      style={{ '--src': `url(${'/assets/riverwalk_aerial_view.png'})` }}>
      <div className={styles.flex_row}>
        <div className={styles.flex_col}>
          <div
            className={styles.content_box}
            style={{ '--src': `url(${'/assets/7ed1573cf03fd3e1bb45ec1d4f823560.svg'})` }}>
            <div className={styles.flex_row1}>
              <h2 className={styles.medium_title1}>search by ip address</h2>
              <img className={styles.image1} src={'/assets/fefc1f493e3935729f1ce17ab6cace25.svg'} alt="alt text" />
            </div>
          </div>

          <div
            className={styles.content_box1}
            style={{ '--src': `url(${'/assets/68a0721e955de5b5a32c130dcdba6036.svg'})` }}>
            <div className={styles.flex_row2}>
              <h2 className={styles.medium_title}>domain search</h2>
              <img className={styles.image1} src={'/assets/fefc1f493e3935729f1ce17ab6cace25.svg'} alt="alt text" />
            </div>
          </div>
        </div>

        <img className={styles.image2} src={'/assets/a3d40e27b223a649cdb04ac3ce4f27b6.svg'} alt="alt text" />
      </div>
    </div>
  );
}

UntitledPage.propTypes = {
  className: PropTypes.string
};

export default UntitledPage;
