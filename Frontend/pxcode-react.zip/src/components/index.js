import UntitledPage from './UntitledPage';

export default { UntitledPage };
